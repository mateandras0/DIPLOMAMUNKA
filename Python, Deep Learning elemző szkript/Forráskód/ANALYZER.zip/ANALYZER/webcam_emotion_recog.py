import cv2
import numpy as np
import tensorflow as tf
from tensorflow import keras
from keras.preprocessing.image import ImageDataGenerator  #képek beolvasásához
from keras.models import Sequential  # tensorflow neurális háló létrehozásához
from keras.layers import Dense, Dropout, Conv2D, MaxPooling2D, Flatten, BatchNormalization  #neurális hálózati rétegek kialakításához
from pathlib import Path

training_generator = ImageDataGenerator(1./255, rotation_range=7, horizontal_flip=True, zoom_range=0.2)
train_dataset = training_generator.flow_from_directory('dataset/train', target_size=(48,48), batch_size=16, class_mode='categorical', shuffle=True)

test_generator = ImageDataGenerator(rescale=1./255)
test_dataset = test_generator.flow_from_directory('dataset/test', target_size=(48,48), batch_size=1, class_mode='categorical', shuffle=False)

with open('network_emotions.json', 'r') as json_file:
    json_saved_model = json_file.read()


network_loaded = tf.keras.models.model_from_json(json_saved_model)
network_loaded.load_weights('weights_emotions.hdf5')
network_loaded.compile(loss='categorical_crossentropy', optimizer='Adam', metrics=['accuracy'])

network_loaded.evaluate(test_dataset)

predictions = network_loaded.predict(test_dataset)

predictions = np.argmax(predictions, axis=1)

emotions = ['angry', 'disgust', 'fear', 'happy', 'neutral', 'sad', 'surprise']

detector = cv2.CascadeClassifier('own_haarcascade.xml')

video_capture = cv2.VideoCapture(0) # elsőszámú webkamerához nullás paraméter, egyéb csatlakoztatott kamerához 1




rectangle_height = 140
rectangle_width = 30

angry_rect_start_point = (50, 150)
disgust_rect_start_point = (90, 150)
fear_rect_start_point = (130, 150)
happiness_rect_start_point = (170, 150)
neutral_rect_start_point = (210, 150)
sad_rect_start_point = (250, 150)
surprise_rect_start_point = (290, 150)


rect_dimension = (60, 140)
thickness = 3
color_valid = (255, 0, 0)
color_invalid = (0, 0, 255)
prediction_max = 1






while True:

    # a webkamera videója képkockánként
    ret, frame = video_capture.read()
    frame_gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = detector.detectMultiScale(frame_gray, scaleFactor=1.2, minNeighbors=8, minSize=(200,200))
    if len(faces) > 0:
        for(x_pos, y_pos, width, height) in faces:
            frame = cv2.rectangle(frame, (x_pos, y_pos), (x_pos + width, y_pos + height), (0, 255, 0), 1)
            roi = frame[y_pos:y_pos + height, x_pos:x_pos + width]
            roi = cv2.resize(roi, (48,48))
            roi = roi / 255
            roi = np.expand_dims(roi, axis=0)
            #print(roi.shape)
            #print(frame.shape)
            prediction = network_loaded.predict(roi)

            prediction_angry = prediction[0][0]
            prediction_disgust = prediction[0][1]
            prediction_fear = prediction[0][2]
            prediction_happy = prediction[0][3]
            prediction_neutral = prediction[0][4]
            prediction_sad = prediction[0][5]
            prediction_surprise = prediction[0][6]

            #print(prediction[0][3])
            #print(type(prediction))

            rect_pred_height_angry = int(prediction_angry * rectangle_height)
            rect_pred_height_disgust = int(prediction_disgust * rectangle_height)
            rect_pred_height_fear = int(prediction_fear * rectangle_height)
            rect_pred_height_happy = int(prediction_happy * rectangle_height)
            rect_pred_height_neutral = int(prediction_neutral * rectangle_height)
            rect_pred_height_sad = int(prediction_sad * rectangle_height)
            rect_pred_height_surprise = int(prediction_surprise * rectangle_height)

            #print(rect_pred_height)

            frame = cv2.rectangle(frame, angry_rect_start_point, (angry_rect_start_point[0] - rectangle_width, angry_rect_start_point[1] - rectangle_height), (0, 255, 0), 1)
            frame = cv2.rectangle(frame, angry_rect_start_point, (angry_rect_start_point[0] - rectangle_width, angry_rect_start_point[1] - rect_pred_height_angry), (0, 255, 0), -1)
            cv2.putText(frame, 'angry', (angry_rect_start_point[0]-33, angry_rect_start_point[1]+10), cv2.FONT_HERSHEY_COMPLEX, 0.35, (0, 255, 0), 1, cv2.LINE_AA)

            frame = cv2.rectangle(frame, disgust_rect_start_point, (disgust_rect_start_point[0] - rectangle_width, disgust_rect_start_point[1] - rectangle_height), (0, 255, 0), 1)
            frame = cv2.rectangle(frame, disgust_rect_start_point, (disgust_rect_start_point[0] - rectangle_width, disgust_rect_start_point[1] - rect_pred_height_disgust), (0, 255, 0), -1)
            cv2.putText(frame, 'disgust', (disgust_rect_start_point[0]-35, disgust_rect_start_point[1]+10), cv2.FONT_HERSHEY_COMPLEX, 0.35, (0, 255, 0), 1, cv2.LINE_AA)

            frame = cv2.rectangle(frame, fear_rect_start_point, (fear_rect_start_point[0] - rectangle_width, fear_rect_start_point[1] - rectangle_height), (0, 255, 0), 1)
            frame = cv2.rectangle(frame, fear_rect_start_point, (fear_rect_start_point[0] - rectangle_width, fear_rect_start_point[1] - rect_pred_height_fear), (0, 255, 0), -1)
            cv2.putText(frame, 'fear', (fear_rect_start_point[0]-27, fear_rect_start_point[1]+10), cv2.FONT_HERSHEY_COMPLEX, 0.35, (0, 255, 0), 1, cv2.LINE_AA)

            frame = cv2.rectangle(frame, happiness_rect_start_point, (happiness_rect_start_point[0] - rectangle_width, happiness_rect_start_point[1] - rectangle_height), (0, 255, 0), 1)
            frame = cv2.rectangle(frame, happiness_rect_start_point, (happiness_rect_start_point[0] - rectangle_width, happiness_rect_start_point[1] - rect_pred_height_happy), (0, 255, 0), -1)
            cv2.putText(frame, 'happy', (happiness_rect_start_point[0]-33, happiness_rect_start_point[1]+10), cv2.FONT_HERSHEY_COMPLEX, 0.35, (0, 255, 0), 1, cv2.LINE_AA)

            frame = cv2.rectangle(frame, neutral_rect_start_point, (neutral_rect_start_point[0] - rectangle_width, neutral_rect_start_point[1] - rectangle_height), (0, 255, 0), 1)
            frame = cv2.rectangle(frame, neutral_rect_start_point, (neutral_rect_start_point[0] - rectangle_width, neutral_rect_start_point[1] - rect_pred_height_neutral), (0, 255, 0), -1)
            cv2.putText(frame, 'neutral', (neutral_rect_start_point[0]-33, neutral_rect_start_point[1]+10), cv2.FONT_HERSHEY_COMPLEX, 0.35, (0, 255, 0), 1, cv2.LINE_AA)

            frame = cv2.rectangle(frame, sad_rect_start_point, (sad_rect_start_point[0] - rectangle_width, sad_rect_start_point[1] - rectangle_height), (0, 255, 0), 1)
            frame = cv2.rectangle(frame, sad_rect_start_point, (sad_rect_start_point[0] - rectangle_width, sad_rect_start_point[1] - rect_pred_height_sad), (0, 255, 0), -1)
            cv2.putText(frame, 'sad', (sad_rect_start_point[0]-25, sad_rect_start_point[1]+10), cv2.FONT_HERSHEY_COMPLEX, 0.35, (0, 255, 0), 1, cv2.LINE_AA)

            frame = cv2.rectangle(frame, surprise_rect_start_point, (surprise_rect_start_point[0] - rectangle_width, surprise_rect_start_point[1] - rectangle_height), (0, 255, 0), 1)
            frame = cv2.rectangle(frame, surprise_rect_start_point, (surprise_rect_start_point[0] - rectangle_width, surprise_rect_start_point[1] - rect_pred_height_surprise), (0, 255, 0), -1)
            cv2.putText(frame, 'surprise', (surprise_rect_start_point[0]-35, surprise_rect_start_point[1]+10), cv2.FONT_HERSHEY_COMPLEX, 0.35, (0, 255, 0), 1, cv2.LINE_AA)


        if prediction is not None:
            result = np.argmax(prediction)
            cv2.putText(frame, emotions[result], (x_pos, y_pos-3), cv2.FONT_HERSHEY_COMPLEX, 0.6, (0, 255, 0), 1, cv2.LINE_AA)
    cv2.imshow('Video', frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

video_capture.release()
cv2.destroyAllWindows()




