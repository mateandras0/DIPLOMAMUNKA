#pip install opencv-python
import cv2

detector = cv2.CascadeClassifier('own_haarcascade.xml')

video_capture = cv2.VideoCapture(0) # elsőszámú webkamerához nullás paraméter, egyéb csatlakoztatott kamerához 1

while True:

    # a webkamera videója képkockánként
    ret, frame = video_capture.read()
    frame_gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    detections = detector.detectMultiScale(frame_gray) #minSize=(200, 200)
    for(x_pos, y_pos, width, height) in detections:
        print(width, height)
        cv2.rectangle(frame, (x_pos, y_pos), (x_pos+width, y_pos+height), (0, 255, 0), 3)
    cv2.imshow('Video', frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

video_capture.release()
cv2.destroyAllWindows()

